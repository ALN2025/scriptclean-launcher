<div align="center">

# ScriptClean — Instalar ScriptBot v3.0

**Bot de atendimento WhatsApp profissional**

🌐 [scriptclean.com.br](https://scriptclean.com.br) · ScriptClean -Solutions-

![Node.js](https://img.shields.io/badge/Node.js-18%2B-339933?style=flat-square&logo=node.js)
![Windows](https://img.shields.io/badge/Windows-10%2F11-0078D6?style=flat-square&logo=windows)
![Versão](https://img.shields.io/badge/ScriptBot-v3.0-blueviolet?style=flat-square)

</div>

---

Este repositório é o **instalador público** do ScriptBot.  
O código completo do bot fica em repositório **privado** licenciado (`ALN2025/bot-whatsapp`).

## Estrutura deste repositório

```
scriptclean-launcher/
├── README.md                    ← este guia
├── Instalar-ScriptClean.bat     ← instalador (clona o bot privado)
├── config/
│   └── license-db.config.json   ← a ScriptClean envia após a compra
└── ScriptClean-Setup.exe        ← opcional (ou via GitHub Releases)
```

---

## Requisitos

| Item | Link |
|------|------|
| Windows 10 ou 11 | — |
| Node.js 18+ | [nodejs.org](https://nodejs.org) |
| Git | [git-scm.com](https://git-scm.com) |

---

## O que a ScriptClean envia após a compra

Envie por WhatsApp ou e-mail **somente ao cliente**:

1. **`config/license-db.config.json`** — conexão com servidor de licenças
2. **Token GitHub** (leitura do repo privado `bot-whatsapp`)
3. Opcional: **`ScriptClean-Setup.exe`**

> O cliente **não** cria o token — você (ScriptClean) gera e envia após a venda.

---

## Instalação — passo a passo (cliente)

### 1. Baixe este repositório

```bat
git clone https://github.com/ALN2025/scriptclean-launcher.git
cd scriptclean-launcher
```

Ou baixe o ZIP em **Code → Download ZIP**.

### 2. Coloque os arquivos recebidos da ScriptClean

```
scriptclean-launcher/
├── config/
│   └── license-db.config.json   ← coloque aqui
├── ScriptClean-Setup.exe        ← se recebeu
└── Instalar-ScriptClean.bat
```

### 3. Execute o instalador

Duplo clique em **`Instalar-ScriptClean.bat`**

O script irá:

1. Pedir o **token GitHub** (enviado pela ScriptClean)
2. Clonar o bot do repo privado `bot-whatsapp`
3. Rodar `npm install`
4. Executar **`ScriptClean-Setup.exe`** (registra licença na VPS)
5. Criar atalhos **ScriptBot - Iniciar** e **ScriptBot - Reiniciar**

### 4. Inicie o bot

Use o atalho na área de trabalho: **ScriptBot - Iniciar**

---

## Trial, licença e renovação

| Regra | Detalhe |
|-------|---------|
| **Trial** | 2 dias de teste |
| **Início do trial** | Na **primeira vez** que o bot ligar (não na instalação) |
| **1 PC = 1 trial** | Vinculado ao hardware (MEK/HWID) — reinstalar não reinicia o trial |
| **Chave de licença** | Exibida no setup: `SC-XXXXXXXX` — guarde para renovação |
| **Após expirar** | Bot bloqueia até a ScriptClean renovar no servidor |

Para renovar, envie sua **chave de licença** pelo WhatsApp da ScriptClean.

---

## Comandos úteis (admin do bot)

No privado do WhatsApp, do número admin configurado:

| Comando | Função |
|---------|--------|
| `#painel` | Painel admin (leads, monitor, estatísticas) |
| `#licenca` | Ver status da licença e MEK |
| `#rr` | Reiniciar o bot |
| `#exportar` | Enviar CSV, Excel e PDF dos leads |

---

## Suporte

- **Site:** [scriptclean.com.br](https://scriptclean.com.br)
- **WhatsApp:** número informado na compra

---

## Para a ScriptClean (uso interno)

<details>
<summary>Como gerar token GitHub para o cliente</summary>

1. GitHub → **Settings** → **Developer settings** → **Fine-grained tokens**
2. Repository access: **Only** `ALN2025/bot-whatsapp`
3. Permissions: **Contents → Read-only**
4. Envie o token ao cliente após a compra

</details>

<details>
<summary>Renovar licença no Navicat (banco acis_aln)</summary>

```sql
UPDATE licenses
SET status = 'active',
    license_expires_at = '2027-12-31 23:59:59',
    notes = 'Cliente renovado'
WHERE license_key = 'SC-XXXXXXXX';
```

</details>

<details>
<summary>Alternativa: instalar via ZIP na VPS (sem token GitHub)</summary>

Hospede um ZIP do bot no seu servidor e altere o `.bat` para baixar o ZIP em vez de clonar o repo privado.

</details>

---

*Código do bot: repositório privado licenciado. Não copiar, não redistribuir.*

**Dev ⩿ A.L.N/⪀** · ScriptClean -Solutions- · BUILD 2026
